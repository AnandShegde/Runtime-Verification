g++  src/main.cpp src/tree.cpp src/consts.cpp -o bin/construct_monitor.out
./bin/construct_monitor.out $1